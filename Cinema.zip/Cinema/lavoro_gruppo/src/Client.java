// Client.java
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 12345;

        try (Socket socket = new Socket(hostname, port)) {
            System.out.println("Connesso al server " + hostname + ":" + port);

            try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                Scanner scanner = new Scanner(System.in)
            ) {
                boolean continua = true;

                while (continua) {
                    System.out.print("Inserisci un nome (o digita 'exit' per uscire): ");
                    String nome = scanner.nextLine();

                    if (nome.equalsIgnoreCase("exit")) {
                        continua = false;
                    } else {
                        writer.println(nome);
                        String risposta = reader.readLine();
                        System.out.println("Risposta dal server: " + risposta);
                        risposta = reader.readLine();
                        System.out.println(risposta);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Errore di connessione: " + e.getMessage());
        }
    }
}
