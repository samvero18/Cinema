import java.io.IOException;

public class ClientLauncher {
    public static void launchClient(int numberOfClients) throws IOException {
        for (int i = 0; i < numberOfClients; i++) { // Lancia più client
            new ProcessBuilder("java", "-cp", "out", "Client").start();
        }
    }
}
