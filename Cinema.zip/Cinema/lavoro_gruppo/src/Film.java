import java.util.ArrayList;
import java.util.List;

public class Film {
    private String nome;
    private String orario;
    private List<String> posti;

    public Film(String nome, String orario, List<String> posti) {
        this.nome = nome;
        this.orario = orario;
        this.posti = posti;
    }

    public String getNome() {
        return nome;
    }

    public String getOrario() {
        return orario;
    }

    public List<String> getPosti() {
        return posti;
    }

    public boolean occupaPosto(String posto) {
        int index = posti.indexOf(posto);
        if (index != -1 && !posti.get(index).equals("x")) {
            posti.set(index, "x"); // Segna il posto come occupato
            return true;
        }
        return false; // Posto già occupato o non trovato
    }

    public synchronized List<String> getPostiDisponibili() {
        return new ArrayList<>(posti);
    }

    @Override
    public String toString() {
        return "Film: " + nome + ", Orario: " + orario + ", Posti disponibili: " + posti;
    }
}