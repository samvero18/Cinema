// Server.java
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static final List<String> nomiSalvati = new ArrayList<>();

    public static void main(String[] args) {
        int port = 12345;
        
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server in ascolto sulla porta " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuovo client connesso");

                try (
                    BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)
                ) {
                    String nome = reader.readLine();
                    if (nome != null) {
                        nomiSalvati.add(nome);
                        writer.println("Nome salvato: " + nome);
                        // writer.println("Nomi salvati finora: " + nomiSalvati);
                    }
                } catch (IOException e) {
                    System.err.println("Errore nella comunicazione con il client: " + e.getMessage());
                } finally {
                    clientSocket.close();
                }
            }
        } catch (IOException e) {
            System.err.println("Errore nell'avvio del server: " + e.getMessage());
        }
    }
}
